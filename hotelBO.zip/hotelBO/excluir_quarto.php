<?php
// Inclua o arquivo de configuração do banco de dados (db.php)
include("db.php");

// Verifique se o número do quarto a ser excluído foi fornecido na URL
if (isset($_GET["numero"])) {
    $numero = $_GET["numero"];

    // Query para excluir o quarto com o número especificado
    $query = "DELETE FROM quarto WHERE numero = $numero";

    if (mysqli_query($conn, $query)) {
        // Redirecionar para a página de quartos após a exclusão bem-sucedida
        header("Location: quarto.php");
    } else {
        echo "Erro ao excluir o quarto: " . mysqli_error($conn);
    }

    // Feche a conexão com o banco de dados
    mysqli_close($conn);
} else {
    echo "Número do quarto não especificado.";
}
?>
