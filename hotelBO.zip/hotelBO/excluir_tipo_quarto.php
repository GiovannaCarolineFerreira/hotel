<?php
// Inclua o arquivo de configuração do banco de dados (db.php)
include("db.php");

// Verifique se o ID do tipo de quarto a ser excluído foi fornecido na URL
if (isset($_GET["id"])) {
    $id = $_GET["id"];

    // Query para excluir o tipo de quarto com o ID especificado
    $query = "DELETE FROM tipo_quarto WHERE id = $id";

    if (mysqli_query($conn, $query)) {
        // Redirecionar para a página de tipos de quarto após a exclusão bem-sucedida
        header("Location: tipo_quarto.php");
    } else {
        echo "Erro ao excluir o tipo de quarto: " . mysqli_error($conn);
    }

    // Feche a conexão com o banco de dados
    mysqli_close($conn);
} else {
    echo "ID do tipo de quarto não especificado.";
}
?>
