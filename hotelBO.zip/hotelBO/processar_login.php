<?php
session_start();
include("db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Verifica se o usuário é "admin" e a senha é "admin1234"
    if ($username === "admin" && $password === "admin1234") {
        $_SESSION["username"] = $username;
        header("Location: home.php"); 
        exit();
    } else {
        //  inválidado
        $_SESSION["login_error"] = "Credenciais inválidas. Tente novamente.";
        header("Location: login.php"); 
        exit();
    }
}

mysqli_close($conn);
?>
