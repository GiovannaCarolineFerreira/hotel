<?php
// Inclua o arquivo de configuração do banco de dados (db.php)
include("db.php");

// Verifique se o ID do funcionário a ser excluído foi fornecido na URL
if (isset($_GET["id"])) {
    $id = $_GET["id"];

    // Query para excluir o funcionário com o ID especificado
    $query = "DELETE FROM funcionario WHERE id = $id";

    if (mysqli_query($conn, $query)) {
        // Redirecionar para a página de funcionários após a exclusão bem-sucedida
        header("Location: funcionario.php");
    } else {
        echo "Erro ao excluir o funcionário: " . mysqli_error($conn);
    }

    // Feche a conexão com o banco de dados
    mysqli_close($conn);
} else {
    echo "ID do funcionário não especificado.";
}
?>

