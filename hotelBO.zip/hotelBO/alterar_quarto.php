<?php
// Inclua o arquivo de configuração do banco de dados (db.php)
include("db.php");

// Inicialize variáveis
$numero = "";
$nome = "";
$preco = "";

// Verifique se o número do quarto foi fornecido na URL
if (isset($_GET["numero"])) {
    $numero = $_GET["numero"];

    // Consulta para obter os dados do quarto com o número especificado
    $query = "SELECT * FROM quarto WHERE numero = $numero";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        $nome = $row["nome"];
        $preco = $row["preco"];
    } else {
        echo "Quarto não encontrado.";
    }
}

// Processamento do formulário de alteração
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST["nome"];
    $preco = $_POST["preco"];
    
    // Consulta para atualizar os dados do quarto
    $query = "UPDATE quarto SET nome = '$nome', preco = '$preco' WHERE numero = $numero";

    if (mysqli_query($conn, $query)) {
        // Redirecionar para a página de quartos após a alteração bem-sucedida
        header("Location: quarto.php");
    } else {
        echo "Erro ao atualizar o quarto: " . mysqli_error($conn);
    }
}

// Feche a conexão com o banco de dados
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alterar Quarto - Ocean Blue Hotel</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="header">
    <h1><a href="home.php">Ocean Blue Hotel</a></h1>
        <p></p>
    </div>
    <div class="menu">
        <!-- Adicione links para outras páginas CRUD aqui -->
    </div>
    <div class="content">
        <h2>Alterar Quarto</h2>
        <form action="alterar_quarto.php?numero=<?php echo $numero; ?>" method="POST">
            <!-- Adicione campos do formulário com os valores preenchidos -->
            <!-- Exemplo: -->
            <label for="nome">Nome:</label>
            <input type="text" name="nome" value="<?php echo $nome; ?>" required>
            <label for="preco">Preço:</label>
            <input type="text" name="preco" value="<?php echo $preco; ?>" required>
            <!-- Botão para salvar as alterações -->
            <button type="submit">Salvar Alterações</button>
        </form>
    </div>
</body>
</html>
