<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recupera os dados do formulário
    $nomeCompleto = $_POST["nome_completo"];
    $email = $_POST["email"];
    $salario = $_POST["salario"];

    // Conexão com o banco de dados 
    $conexao = new mysqli("localhost", "usuario", "senha", "banco");
    if ($conexao->connect_error) {
        die("Conexão falhou: " . $conexao->connect_error);
    }

    // Inserir o novo funcionário no banco de dados
    $query = "INSERT INTO funcionario (nome_completo, email, salario) VALUES ('$nomeCompleto', '$email', $salario)";
    if ($conexao->query($query) === TRUE) {
        echo "Funcionário adicionado com sucesso!";
    } else {
        echo "Erro ao adicionar funcionário: " . $conexao->error;
    }

    // Fechar a conexão com o banco de dados
    $conexao->close();
}
?>
<br>
<a href="funcionario/funcionario.php">Voltar para a Tabela</a