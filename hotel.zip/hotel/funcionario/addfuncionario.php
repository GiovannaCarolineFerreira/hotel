<!DOCTYPE html>
<html>
<head>
    <title>Adicionar Funcionário</title>
</head>
<body>
    <h2>Adicionar Funcionário</h2>
    <form method="post" action="processa_addfuncionario.php">
        Nome Completo: <input type="text" name="nome_completo"><br><br>
        Email: <input type="email" name="email"><br><br>
        Salário: <input type="number" name="salario"><br><br>
        <input type="submit" value="Adicionar">
    </form>
    <br>
    <a href="funcionario/funcionario.php">Voltar para a Tabela</a>
</body>
</html>
