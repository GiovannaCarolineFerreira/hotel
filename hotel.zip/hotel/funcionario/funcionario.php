<!DOCTYPE html>
<html>
<head>
    <title>Tabela de Funcionários</title>
</head>
<body>
    <h2>Tabela de Funcionários</h2>
    <a href="addfuncionario.php">Adicionar Funcionário</a>
    <br><br>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Nome Completo</th>
            <th>Email</th>
            <th>Salário</th>
            <th>Ações</th>
        </tr>
        <?php
        // Conexão com o banco de dados
        $conexao = new mysqli("localhost", "usuario", "senha", "banco");
        if ($conexao->connect_error) {
            die("Conexão falhou: " . $conexao->connect_error);
        }

        // Consulta SQL para obter os funcionários
        $query = "SELECT id, nome_completo, email, salario FROM ";
        $resultado = $conexao->query($query);

        // Exibir os resultados na tabela
        if ($resultado->num_rows > 0) {
            while ($row = $resultado->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["id"] . "</td>";
                echo "<td>" . $row["nome_completo"] . "</td>";
                echo "<td>" . $row["email"] . "</td>";
                echo "<td>" . $row["salario"] . "</td>";
                echo "<td><a href='editar_funcionario.php?id=" . $row["id"] . "'>Editar</a> | <a href='excluir_funcionario.php?id=" . $row["id"] . "'>Excluir</a></td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='5'>Nenhum funcionário encontrado.</td></tr>";
        }

        // Fechar a conexão com o banco de dados
        $conexao->close();
        ?>
    </table>
</body>
</html>