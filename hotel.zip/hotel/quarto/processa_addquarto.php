<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recuperar os dados do formulário
    $descricao = $_POST["descricao"];
    $preco = $_POST["preco"];
    $codigo = $_POST["codigo"];

    // Conexão com o banco de dados 
    $conexao = new mysqli("localhost", "usuario", "senha", "banco");
    if ($conexao->connect_error) {
        die("Conexão falhou: " . $conexao->connect_error);
    }

    // Inserir o novo quarto no banco de dados
    $query = "INSERT INTO tipo_quarto (descricao, preco, codigo) VALUES ('$descricao', $preco, '$codigo')";
    if ($conexao->query($query) === TRUE) {
        echo "Quarto adicionado com sucesso!";
    } else {
        echo "Erro ao adicionar quarto: " . $conexao->error;
    }

    // Fechar a conexão com o banco de dados
    $conexao->close();
}
?>
<br>
<a href="index.php">Voltar para a Tabela</a>

