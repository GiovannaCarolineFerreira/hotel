<!DOCTYPE html>
<html>
<head>
    <title>Tabela de Quartos</title>
</head>
<body>
    <h2>Tabela de Quartos</h2>
    <a href="addquarto.php">Adicionar Quarto</a>
    <br><br>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Tipo de Quarto</th>
            <th>Preço</th>
            <th>Descrição</th>
            <th>Ações</th>
        </tr>
        <?php
        // Conexão com o banco de dados
        $conexao = new mysqli("localhost", "usuario", "senha", "banco");
        if ($conexao->connect_error) {
            die("Conexão falhou: " . $conexao->connect_error);
        }

        // Consulta SQL para obter os quartos
        $query = "SELECT id, descricao, codigo, preco FROM tipo_quarto";
        $resultado = $conexao->query($query);

        // Exibir os resultados na tabela
        if ($resultado->num_rows > 0) {
            while ($row = $resultado->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["id"] . "</td>";
                echo "<td>" . $row["descricao"] . "</td>";
                echo "<td>" . $row["preco"] . "</td>";
                echo "<td>" . $row["codigo"] . "</td>";
                echo "<td><a href='modifica_quarto.php?id=" . $row["id"] . "'>Editar</a> | <a href='excluir_quarto.php?id=" . $row["id"] . "'>Excluir</a></td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='5'>Nenhum quarto encontrado.</td></tr>";
        }

        // Fecha a conexão com o banco de dados
        $conexao->close();
        ?>
    </table>
</body>
</html>