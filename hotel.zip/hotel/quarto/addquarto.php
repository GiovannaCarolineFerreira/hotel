<!DOCTYPE html>
<html>
<head>
    <title>Adicionar Quarto</title>
</head>
<body>
    <h2>Adicionar Quarto</h2>
    <form method="post" action="processa_addquarto.php">
        Tipo de Quarto: <input type="text" name="descricao"><br><br>
        Preço: <input type="number" name="preco"><br><br>
        Código: <input type="text" name="codigo"><br><br>
        <input type="submit" value="Adicionar">
    </form>
    <br>
    <a href="index.php">Voltar para a Tabela</a>
</body>
</html>