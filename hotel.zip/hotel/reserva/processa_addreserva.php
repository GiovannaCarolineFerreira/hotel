<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $tipo_quarto = $_POST["tipo_quarto"];
    $nome_cliente = $_POST["nome_cliente"];
    $data_entrada = $_POST["data_entrada"];
    $data_saida = $_POST["data_saida"];

    $conexao = new mysqli("127.0.0.1", "root", "root", "hotel");
    if ($conexao->connect_error) {
        die("Conexão falhou: " . $conexao->connect_error);
    }


    $query = "INSERT INTO reserva (tipo_quarto, nome_cliente, data_entrada, data_saida) VALUES ('$descricao', $preco, '$codigo')";
    if ($conexao->query($query) === TRUE) {
        echo "Reserva adicionado com sucesso!";
    } else {
        echo "Erro ao adicionar reserva: " . $conexao->error;
    }


    $conexao->close();
}
?>
<br>
<a href="reserva/reserva.php">Ir para a Tabela</a>

create table reserva
  id integer,
  tipo_quarto int,
  nome_cliente int,
  data_entrada date,
  data_saida date,
  primary key (id),
  foreign key (tipo_quarto) references tipo_quarto(id),
  foreign key (nome_cliente) references cliente(id)