<!DOCTYPE html>
<html>
<head>
    <title>Adicionar Reserva</title>
</head>
<body>
    <h2>Adicionar Reserva</h2>
    <form method="post" action="processa_addreserva.php">
        Tipo de Quarto: <input type="text" name="tipo_quarto"><br><br>
        Nome do Cliente: <input type="text" name="nome_cliente"><br><br>
        Data Entrada: <input type="text" name="data_saida"><br><br>
        Data Saida: <input type="text" name="data_saida"><br><br>
        <input type="submit" value="Adicionar">
    </form>
    <br>
    <a href="reserva/reserva.php">Ir para a Tabela</a>
</body>
</html>
create table reserva
  id integer,
  tipo_quarto int,
  nome_cliente int,
  data_entrada date,
  data_saida date,
  primary key (id),
  foreign key (tipo_quarto) references tipo_quarto(id),
  foreign key (nome_cliente) references cliente(id)