<!DOCTYPE html>
<html>
<head>
    <title>Tabela de Quartos</title>
</head>
<body>
    <h2>Tabela de Quartos</h2>
    <a href="addreserva.php">Adicionar Reserva</a>
    <br><br>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Tipo de Quarto</th>
            <th>Nome - Cliente</th>
            <th>Data de Entrada</th>
            <th>Data de Saida</th>
        </tr>
        <?php
        // Conexão com o banco de dados
        $conexao = new mysqli("", "root", "root", "hotel");
        if ($conexao->connect_error) {
            die("Conexão falhou: " . $conexao->connect_error);
        }

        // Consulta SQL para obter as reservas
        $query = "SELECT id, tipo_quarto, nome_cliente, data_entrada, data_saida FROM reserva";
        $resultado = $conexao->query($query);

        // Exibir os resultados na tabela
        if ($resultado->num_rows > 0) {
            while ($row = $resultado->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["id"] . "</td>";
                echo "<td>" . $row["tipo_quarto"] . "</td>";
                echo "<td>" . $row["nome_cliente"] . "</td>";
                echo "<td>" . $row["data_entrada"] . "</td>";
                echo "<td>" . $row["data_saida"] . "</td>";
                echo "<td><a href='modifica_reserva.php?id=" . $row["id"] . "'>Editar</a> | <a href='excluir_quarto.php?id=" . $row["id"] . "'>Excluir</a></td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='5'>Nenhum quarto encontrado.</td></tr>";
        }

        // Fecha a conexão com o banco de dados
        $conexao->close();
        ?>
    </table>
</body>
</html>