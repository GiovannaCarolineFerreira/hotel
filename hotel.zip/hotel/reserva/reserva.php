<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reserva</title>
    create table reserva(
  id integer,
  tipo_quarto int,
  nome_cliente int,
  data_entrada date,
  data_saida date,
  primary key (id),
  foreign key (tipo_quarto) references tipo_quarto(id),
  foreign key (nome_cliente) references cliente(id)
);
</head>
<body>
    
</body>
</html>