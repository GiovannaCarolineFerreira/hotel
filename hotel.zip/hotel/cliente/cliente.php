  create table cliente(
  id integer,
  nome varchar(205),
  cidade varchar(205),
  telefone varchar(205),
  email varchar(205),
  primary key(id)
)
<!DOCTYPE html>
<html>
<head>
    <title>Tabela de Cliente</title>
</head>
<body>
    <h2>Clientes</h2>
    <a href="adicionar_cliente.php">Adicionar Cliente</a>
    <br><br>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Nome Completo</th>
            <th>Cidade</th>
            <th>Email</th>
            <th>telefone</th>
            <th>Ações</th>
        </tr>
        <?php

        $conexao = new mysqli("localhost", "usuario", "senha", "banco");
        if ($conexao->connect_error) {
            die("Conexão falhou: " . $conexao->connect_error);
        }

        // Consulta SQL para obter os clientes
        $query = "SELECT id, nome_completo, cidade, email, telefone FROM cliente";
        $resultado = $conexao->query($query);

        // Exibir os resultados na tabela
        if ($resultado->num_rows > 0) {
            while ($row = $resultado->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row["id"] . "</td>";
                echo "<td>" . $row["nome_completo"] . "</td>";
                echo "<td>" . $row["cidade"] . "</td>";
                echo "<td>" . $row["email"] . "</td>";
                echo "<td>" . $row["telefone"] . "</td>";
                echo "<td><a href='cliente/edit_cliente.php?id=" . $row["id"] . "'>Editar</a> | <a href='excluir_cliente.php?id=" . $row["id"] . "'>Excluir</a></td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='5'>Nenhum cliente encontrado.</td></tr>";
        }

        // Fecha a conexão com o banco de dados
        $conexao->close();
        ?>
    </table>
</body>
</html>