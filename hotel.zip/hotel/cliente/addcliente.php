<!DOCTYPE html>
<html>
<head>
    <title>Adicionar Cliente</title>
</head>
<body>
    <h2>Adicionar Cliente</h2>
    <form method="post" action="processa_addfuncionario.php">
        Nome Completo: <input type="text" name="nome"><br><br>
        Cidade: <input type="text" name="nome"><br><br>
        Telefone: <input type="number" name="telefone"><br><br>
        Email: <input type="email" name="email"><br><br>
        <input type="submit" value="Adicionar">
    </form>
    <br>
    <a href="cliente/cliente.php">Voltar para a Tabela</a>
</body>
</html>