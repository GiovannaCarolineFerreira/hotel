<!DOCTYPE html>
<html>
<head>
    <title>Adicionar Tipo de Quarto</title>
</head>
<body>
    <h2>Adicionar Tipo de Quarto</h2>
    <form method="post" action="processa_tipoquarto.php">
        : <input type="text" name="descricao"><br><br>
        : <input type="number" name="preco"><br><br>
        : <input type="text" name="codigo"><br><br>
        <input type="submit" value="Adicionar">
    </form>
    <br>
    <a href="index.php">Voltar para a Tabela</a>
</body>
</html>