<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tipo quarto</title>
   

</head>
<body>
    
</body>
</html>
create table tipo_quarto(
  id integer,
  descricao varchar(205),
  codigo varchar(205),
  primary key (id)
);