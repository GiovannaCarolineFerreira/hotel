<?php
session_start();
include("db.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Consulta ao banco de dados para verificar se as credenciais são válidas
    $query = "SELECT * FROM funcionario WHERE login = '$username' AND senha = '$password'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        // Se as credenciais são válidas, inicia a sessão e redireciona para a página inicial
        $_SESSION["username"] = $username;
        header("Location: home.php");
        exit();
    } else {
        // Se as credenciais são inválidas, define uma mensagem de erro e redireciona para a página de login
        $_SESSION["login_error"] = "Credenciais inválidas. Tente novamente.";
        header("Location: login.php");
        exit();
    }
}

mysqli_close($conn);
?>
